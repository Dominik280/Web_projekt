<?php
defined('BASEPATH') OR exit ('No direct script acces allowed');


class Controller extends CI_Controller
{
   public function __construct() {
      parent::__construct();
      $this->load->library('ion_auth');
      $this->load->model('Model');
      $this->load->view('pages/header');

      if(!$this->ion_auth->logged_in())$this->load->view('pages/menu'); //když nejsem přihlášen ->menu
      else if($this->ion_auth->logged_in() && $this->ion_auth->is_admin())$this->load->view('pages/menu_admin'); //když jsem přihlášen a jsem admin ->menu_admin
   }

   
  public function index()
  {
    $this->load->view("pages/home");
  }
 

     public function zamestnanci()  
     {    
           $this->load->library('form_validation');  
           $this->form_validation->set_rules("jmeno", "jmeno", 'required|alpha');  
           $this->form_validation->set_rules("prijmeni", "prijmeni", 'required|alpha');  

           if($this->form_validation->run())  
           {  
                $data = array(  
                     "jmeno"     =>$this->input->post("jmeno"),  
                     "prijmeni"  =>$this->input->post("prijmeni"));  

                if($this->input->post("update"))  
                {  
                     $this->Model->update_data($data, $this->input->post("hidden_id"));  
                     redirect(base_url() . "Controller/updated");  
                }

                if($this->input->post("insert"))  
                {  
                     $this->Model->insert_data($data);  
                     redirect(base_url() . "Controller/inserted");  
                }  
           }  
           else  
           {    
                $data["vyber"] = $this->Model->vyber(); 
                $this->load->view("pages/zamestnanci", $data);    
           }  
     }  
     
      public function inserted()  
      {  
        $data["vyber"] = $this->Model->vyber(); 
        $this->load->view("pages/zamestnanci", $data);    
      }  
      public function delete_data(){  
           $id = $this->uri->segment(3);  
           $this->load->model("Model");  
           $this->Model->delete_data($id);  
           redirect(base_url() . "Controller/deleted");  
      }  

      public function deleted()  
      {  
        $data["vyber"] = $this->Model->vyber(); 
        $this->load->view("pages/zamestnanci", $data);    
      }

      public function update_data(){  
           $user_id = $this->uri->segment(3);  
           $this->load->model("Model");  
           $data["user_data"] = $this->Model->fetch_single_data($user_id);  
           $data["vyber"] = $this->Model->vyber(); 
           $this->load->view("pages/zamestnanci", $data);  
      }  
      
      public function updated()  
      {  
        $data["vyber"] = $this->Model->vyber(); 
        $this->load->view("pages/zamestnanci", $data);    
      }  


     
     public function zakaznici()
     {
          $this->load->library('form_validation');  
           $this->form_validation->set_rules("jmeno", "jmeno", 'required|alpha');  
           $this->form_validation->set_rules("prijmeni", "prijmeni", 'required|alpha');
           $this->form_validation->set_rules("adresa", "adresa");  
           $this->form_validation->set_rules("telefon", "telefon");
           $this->form_validation->set_rules("email", "email", 'required|alpha');

           if($this->form_validation->run())  
           {  
                $data = array(  
                     "jmeno"     =>$this->input->post("jmeno"),  
                     "prijmeni"  =>$this->input->post("prijmeni"),
                     "adresa"    =>$this->input->post("adresa"),  
                     "telefon"   =>$this->input->post("telefon"),  
                     "email"     =>$this->input->post("email"));  

                     if($this->input->post("update"))  
                     {  
                          $this->Model->update_data_zakaznici($data, $this->input->post("hidden_id"));  
                          redirect(base_url() . "Controller/updated_zakaznici");  
                     }
     
                     if($this->input->post("insert"))  
                     {  
                          $this->Model->insert_data_zakaznici($data);  
                          redirect(base_url() . "Controller/inserted_zakaznici");  
                     }  
                }  
                else  
                {    
                     $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
                     $this->load->view("pages/zakaznici", $data);    
                }  
          }  
          
           public function inserted_zakaznici()  
           {  
               $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
               $this->load->view("pages/zakaznici", $data);    
           }  
           public function delete_data_zakaznici(){  
                $id = $this->uri->segment(3);  
                $this->load->model("Model");  
                $this->Model->delete_data_zakaznici($id);  
                redirect(base_url() . "Controller/deleted_zakaznici");  
           }  
     
           public function deleted_zakaznici()  
           {  
               $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
               $this->load->view("pages/zakaznici", $data);    
           }
     
           public function update_data_zakaznici(){  
                $user_id = $this->uri->segment(3);  
                $this->load->model("Model");  
                $data["user_data"] = $this->Model->vypis_jeden_zakaznik($user_id);  
                $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
                $this->load->view("pages/zakaznici", $data);   
           }  
           
           public function updated_zakaznici()  
           {  
               $data["vypis_zakaznici"] = $this->Model->vypis_zakaznici(); 
               $this->load->view("pages/zakaznici", $data);    
           }  
       
     
}

