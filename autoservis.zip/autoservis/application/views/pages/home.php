
<!doctype html>
<html lang="en">
    <style>
      .navbar-marg
      {
        margin-bottom: 25px;
      }
      .nadpis
      {
        text-align: center;
      }
    </style>

    <body>
        <div class= "container">
        <h1 class="nadpis">AUTOSERVIS </h1>
        <p>NĚJAKÝ TEXT, TO SE DOMYSLÍ</p>
    </body>
</html>