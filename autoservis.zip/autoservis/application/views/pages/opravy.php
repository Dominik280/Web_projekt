
<!doctype html>
<html lang="en">
     <title>Opravy</title>
    <style>
      marg
      {
        margin-bottom: 25px;
      }
      .nadpis
      {
        text-align: center;
      }
    </style>
    

    <body>
    <div class="container">  
      <br /><br /><br />  
      <h1 class="nadpis">Opravy</h1><br />  
      <br /><br /><br />  
      <div class="table-responsive">  
           <table class="table table-bordered">  
                <tr>  
                     <th>Datum</th>  
                     <th>Majitel</th>  
                     <th>Registrační značka</th>
                     <th>Výrobce</th>  
                     <th>Název dílu</th>  
                     <th>automechanik</th>  
                     <th>Cena</th>     
                </tr>  
           <?php  
           
                foreach($opravy as $row)  
                {  
           ?>  
                <tr>  
                     <td><?php echo $row->datum; ?></td>  
                     <td><?php echo $row->prijmeni_majitel; ?></td>  
                     <td><?php echo $row->registracni_znacka; ?></td> 
                     <td><?php echo $row->vyrobce; ?></td>
                     <td><?php echo $row->nazev; ?></td>
                     <td><?php echo $row->prijmeni_zamestnanec; ?></td>
                     <td><?php echo $row->cena; ?></td>
                </tr>  
           <?php       
                }  
              
           ?>  
           </table>  
      </div>  
 </div>  
    </body>
</html>